<?php
define( 'WP_CACHE', true );
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'hseviet_nhung' );

/** MySQL database username */
define( 'DB_USER', 'hseviet_nhung' );

/** MySQL database password */
define( 'DB_PASSWORD', 'Violet@0101' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          ']&lMP8tsc/gv_AK}/-7Ku`6]1>S9WKTaeH^kBLjk5sfr3o.{{))>hG zfQ=+N%D{' );
define( 'SECURE_AUTH_KEY',   'Ob05a9`z6t @(C0 *cN5R=j:Hc :>6jmcIe2k| AU7SisF$pM-2lUngr!@`bG`,2' );
define( 'LOGGED_IN_KEY',     '`t)-](IeaUis!i{tg)B9JrA|Yom=%Op-zG5tg7(v2Ha_y*9Gh EX&Jy^Ce4VyafI' );
define( 'NONCE_KEY',         'w+Vmsab)EiO]u#-R<k[+_SKU#7XmMe^E=&Q%An?#k^|EN_3 <BPB_V_$&VQ)qt?o' );
define( 'AUTH_SALT',         'm>af@:OFK8J5a-@C6zKv~aP_!hTs4fs]kDcV/>W~p<u]Se?.a$aphcQl>2C>zOZg' );
define( 'SECURE_AUTH_SALT',  '2h[gvbU-{D.)t-jKNTgR.49U@$.D55#}`RihnBeA[F4]LZ3#Zow(Mtoh!Dw4XqYp' );
define( 'LOGGED_IN_SALT',    'Qb`4D#UGZks18ZRB`/*^TqvA8|U[X$hn5[4mR__$RX?)~f#ThDd=)&fqD^~7gY|Q' );
define( 'NONCE_SALT',        'LXM!C&C2$Fu8*WT&<UD00T^EjaB,C%E*V0XB%JXXaUR`gF5!cFIBy5OT-#)EM3Ah' );
define( 'WP_CACHE_KEY_SALT', 'rD0S[%g^/{1kxH/_1]:FVwi8&SJMA9`.E+Wj_Uo2 xY8Stl|}t:F$2%!nXyE7Dk$' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
